#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main()
{
    int amount, highvalue = 0, totalorders = 0, orderID;
    string customerName, highestName, lowestName;
    int highestVlaue = 0, lowestValue = 0;
    int highestOrderID = 0, lowestOrderID = 0 ;
    int highestAmount = -1, lowestAmount = 9999;
    ifstream fin;
    fin.open("orders.txt");
    if (fin.fail())
    {
        cout << "File is not found:";
        return 1;
    }
    while (fin >> orderID >> amount)
    {
        fin.ignore();
        getline (fin, customerName);
        
        totalorders++;
        if (amount >= 1000)
        {
            highvalue++;
        }
        if (amount > highestVlaue)
        {
           highestVlaue = amount;
           highestName = customerName;
           highestOrderID = orderID;
           
        } 
        if (amount < lowestAmount)
        {
            lowestAmount = amount;
            lowestName = customerName;
            lowestOrderID = orderID;
        }
    }

    fin.close();
    cout << " Highest value" << "out of" << totalorders << "Orders are of high-value order\n:";
    cout <<"\n Highest Order\n:";
    cout << "Highest Name" << " " << highestName  << endl;
    cout << "Highest order ID" << " " << highestOrderID << endl;
    cout << "Amount"<< " " <<highestVlaue << endl;
    cout << "\n lowest order\n";
    cout << "lowestName"<< " " << lowestName << endl;
    cout << "lowestOrderID"<< " " << lowestOrderID << endl;
    cout << "Amount" << lowestAmount << " " << endl;
    return 0;
}
