#include <iostream>
#include <fstream>                             
using namespace std;

int main()
{
    string city;
    int days;

    cout << "Enter city name: ";
    getline(cin, city);

    cout << "Enter number of days: ";
    cin >> days;

    // Writing to file
    ofstream fout ("temperatures.txt");

    float temp;
    for (int i = 1; i <= days; i++)
    {
        cout << "Day " << i << " temperature: ";
        cin >> temp;
        fout << temp << endl;
    }

    fout.close();
    cout << "Data saved to temperature.txt file." <<endl ;

    // First pass: find sum, min, max
    ifstream fin ("temperatures.txt");

    float value, sum = 0;
    float min, max;
    int count = 0;

    while (fin >> value)
    {
        if (count == 0)
        {
            min = max = value;
        }

        if (value < min)
            min = value;

        if (value > max)
            max = value;

        sum += value;
        count++;
    }

    fin.close();

    float avg = sum / count;

    // Second pass: count above average
    ifstream fin2("temperatures.txt");

    int aboveAvg = 0;

    while (fin2 >> value)
    {
        if (value > avg)
            aboveAvg++;
    }

    fin2.close();

    // Output
    cout << " Temperature Analysis for " << city << endl;
    cout << "Min Temp: " << min << endl;
    cout << "Max Temp: " << max << endl;
    cout << "Average: " << avg << endl;
    cout << "Days above average: " << aboveAvg << endl;

    return 0;
}