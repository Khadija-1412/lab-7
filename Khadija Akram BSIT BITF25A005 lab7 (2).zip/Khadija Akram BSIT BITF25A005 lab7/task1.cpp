#include <iostream>
using namespace std;
int main()
{
    int startingNumber, NumberOfRows;
    cout << "Please enter the starting number:";
    cin >> startingNumber;
    cout << "Please enter the number of rows:";
    cin >> NumberOfRows;
    int num = startingNumber;
    for (int i = 1; i <= NumberOfRows; i++)
    {
        for (int j = 1; j <= i; j++)
        {
        cout << num << " ";
        num = num + 3;
        }
        cout << endl;
    }
    return 0;
}